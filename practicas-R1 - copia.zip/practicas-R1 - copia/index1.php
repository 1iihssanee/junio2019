
<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.css">
</head>
<body>
<h1 class="font-weight-normal">Datos personales</h1>
<form action="index1.php" method="get">
    <div class="form-group">
    <label for="nombre">Nombre</label>
    <input type="text" name="nombre" id="nombre" class="form-control"> <br>
        <small id="nombreHelp" class="form-text text-muted"> </small>
    </div>
    <div class="form-group">
    <label for="apellido">Apellido</label>
    <input type="text" name="apellido" id="apellido" class="form-control"> <br>
    </div>
    <div class="form-group">
    <label for="edad">edad</label>
    <input type="number" name="edad" id="edad" min="18" class="form-control"> <br>
    </div>
    <div class="form-group">
        <label for="direccion">direccion</label>
        <input type="number" name="direccion" id="direccion" class="form-control"> <br>
    </div>
    <div class="form-group">
    <label for="cp">CP</label>
    <input type="number" name="cp" id="cp" class="form-control"> <br>
        </div>
    <div class="form-group">
    <button class="btn btn-primary">enviar</button>
    </div>
</form>
<?php
if(isset($_GET["nombre"]) and isset($_GET["apellido"]) and isset($_GET["edad"]) and isset($_GET["direccion"])) {

    $nombre = $_GET["nombre"];
    $apellido = $_GET["apellido"];
    $edad = $_GET["edad"];
    $direccion = $_GET["direccion"];
    $cp = $_GET["cp"];
    if ((strlen($nombre) <= 3) ) {
        echo "<div class='form-group'>";
        echo '<small id="nombreHelp" class="form-text text-muted" style=\'background-color: red\'>El nombre debe de contener al menos 3 caracteres</small>';
        echo "</div>";
    }
        elseif ((strlen($apellido) <= 3)) {
            echo "<div class='form-group'>";
            echo '<small id="apellidoHelp" class="form-text text-muted" style=\'background-color: red\'>El apellido debe de contener al menos 3 caracteres</small>';
            echo "</div>";
        }
          elseif (is_numeric($edad)and $edad>75){
              echo "<div class='form-group'>";
              echo '<small id="edadHelp" class="form-text text-muted" style=\'background-color: red\'>La edad debe ser un número de entre 18 y 75</small>';
              echo "</div>";


        }

          elseif(is_numeric($cp)and (strlen($cp) == 5)){
              echo "<div class='form-group'>";
              echo '<small id="numeroHelp" class="form-text text-muted">datos validos</small>';
              echo "</div>";
          }
          else{
              echo "<div class='form-group'>";
              echo '<small  class="form-text text-muted" style=\'background-color: red\'>tiene que ser 5 </small>';
              echo "</div>";


          }
}



?>
<script></script>
<script src="js/bootstrap.js"></script>
<script src="js/bootstrap.min.js"></script>

</body>
</html>